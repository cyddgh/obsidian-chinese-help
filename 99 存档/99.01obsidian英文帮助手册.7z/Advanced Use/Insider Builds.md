# Insider Builds

If you are a Catalyst supporter, you have access to Insider Builds before the general public. To access these, go to Settings => Account, and log in with the password you used on the Obsidian site. Then go to Settings => About, and turn on Insider Builds there.

![[insider-min.png]]