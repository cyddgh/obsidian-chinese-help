Obsidian recognizes the following file formats right now:

1. Markdown files: `md`;
2. Image files: `png`, `jpg`, `jpeg`;
3. Audio files: `mp3`, `webm`, `wav`, `m4a`, `ogg`, `3gp`, `flac`;
4. PDF files: `pdf`.

Everything except for PDFs can be [[Embed files|embedded]].
