# Slides

Slides lets you do simple presentations right inside Obsidian.

### Usage tips

1. To separate slides, use newlines and the `---` separator.

2. To start a presentation, click this button after opening a note:

![[Pasted image 14.png]]

### Demo

Check out the demo document: [[Slides demo]]
