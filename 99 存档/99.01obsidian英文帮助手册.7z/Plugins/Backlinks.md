# Backlinks 

The backlinks plugin shows how the current note is referenced in other notes.

After enabling it, you'll see the backlink count in the status bar.

In the right side bar (if it's expanded), you should also see a panel that shows where the current note gets linked:

![[Pasted image 9.png]]

Upon expanding the "Unlinked mentions" section, you can also see where the name of the note gets mentioned, but not explicitly linked (in other words, mentioned without the square brackets).
