# Starred Notes

Starred notes are a convenient way of keeping important notes close at hand. Enabling the plugin will create a star icon on the left panel, which brings up a list of starred notes. 

To star a file, you have several options. You can do so from a right click in the file explorer, a click on the options menu of an open note, typing in the [[command palette]], or a hotkey that can be set in [[Keyboard shortcuts]].