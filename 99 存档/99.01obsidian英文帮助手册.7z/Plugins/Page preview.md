# Page Preview

Page preview lets you preview a page when hovering an internal link, without needing to actually navigate to that page.

![[Pasted image 13.png]]

This works on the preview pane. In the editor, you can hover a link while holding `Ctrl/Cmd`, which will open the preview too.
