# Tag Pane

Adds a panel on the right that displays all the tags you have, along with their tag count.

The tags are sorted from mostly frequently used to least frequently used.

When clicking on a tag, a search for the tag is activated.
