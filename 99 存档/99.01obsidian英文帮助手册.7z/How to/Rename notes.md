If you're already editing the note, you can rename it simply by editing the text in the title:

![[Pasted image 6.png]]

If you want to rename a note that you're not editing, go to [[file explorer]], right-click on the note or folder and choose "Rename":

![[Pasted image 7.png]]

An even faster way is to press `F2` while your mouse is over a note, which will take you straight to the renaming function.
