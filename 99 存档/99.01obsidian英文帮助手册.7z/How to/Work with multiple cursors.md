If you hold down `alt` and click, you can create multiple cursors. This can be useful when modifying a lot of lines in the same way, for example putting `-` at the beginning of multiple lines to turn them into a list, or appending `[[` to a series of links you've copied from elsewhere. 

To cancel multiple cursors, either click somewhere in the note (without a modifier key), or hit escape. 