# Audio Recorder

Introduced in [[v0.0.1]], **disabled** by default.

Audio recorder is a plugin that lets you make a recording without leaving Obsidian. It's useful for class and meeting notes when you can't catch up for some reason, or for recording important discussions so you don't miss any details.

To use, simply click on the microphone icon in the left panel:

![[Pasted image 8.png]]

The microphone will become colored while it's actively recording.

Click on it again to finish recording. The audio file is now saved in your [[vault]] and an embed the recording will be added to the end of your current note.
