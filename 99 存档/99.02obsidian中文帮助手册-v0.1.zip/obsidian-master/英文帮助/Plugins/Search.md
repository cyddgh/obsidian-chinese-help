# Search

Introduced in [[v0.0.1]], **enabled** by default.

Search for a keyword in all of your notes.

![[Pasted image 12.png]]

### Usage tips

1. Search is case-insensitive for now.

2. You can click on a search result to go to that note.