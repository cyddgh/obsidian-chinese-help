# Random Note

Introduced in [[v0.5.2]], **disabled** by default.

Random note does just that, opens a note at random from your Vault. Many people find this useful for surfacing thoughts they had not considered in a long time, or spot checking for things that they may have forgotten to link. 