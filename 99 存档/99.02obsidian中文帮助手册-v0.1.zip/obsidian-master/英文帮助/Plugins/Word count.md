# Word Count

Introduced in [[v0.1.0]], **enabled** by default.

Word count is a simple plugin that shows the word count of your current note in the bottom status bar.

It works for CJK characters too (Chinese, Japanese, and Korean), in which words are not separately by spaces but rather glued together.
