# Zettelkasten Prefixer

Introduced in [[v0.5.0]], **disabled** by default.

Adds a new button to the left pane, which can be used to create a new file and prefix it for you using the current time. 

The default format is 12-digit timestamp, e.g. "202001010000". 

For more information on why you would want to do this see the [[Zettelkasten method]].