# Open in Default App

Introduced in [[v0.3.0]], **disabled** by default.

Opens the current file with default app on your computer. You can access it at the top right corner of the file top bar:

![[Pasted image 5.png]]

It's useful for editing images or annotating PDFs, among other things.
