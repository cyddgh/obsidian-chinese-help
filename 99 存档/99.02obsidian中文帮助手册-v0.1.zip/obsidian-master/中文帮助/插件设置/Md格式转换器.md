[[Markdown format converter]]
# Md格式转换器

于[[v0.5.0]]版引入，默认**启用**。

此插件允许你把其他变种的Markdown格式及链接格式转化成Obsidian格式。

现在，您可以实现以下转换：

目前你可以转化的格式

- Roam 标签 #tags 样式转换为 [[tags]] 样式
- Roam 高亮  `^^highlight^^` 样式转换为 `==highlight==` 样式
- Zettelkasten 链接 `[[UID]]` 样式转换为 `[[UID File Name]]` 样式
- Zettelkasten 链接 `[[UID]]` 样式美化为 `[[UID File Name|File Name]]` 样式，它将显示为 `File Name`

---

### 相关链接

- [[格式化你的笔记]]

>翻译：Leon QQ：873663674