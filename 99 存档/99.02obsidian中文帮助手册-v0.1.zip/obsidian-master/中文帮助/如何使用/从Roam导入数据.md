[[Import data from Roam]]

如果您在 Roam 中有数据，那么可以很容易导出并在obsidian中处理它。

> 1. 在选单中选择“全部导出” :

> ![[Pasted image.png]]

> 2. 按一下蓝色的「全部导出」按钮:

> ![[Pasted image 1.png]]


> 3. 将“ roam-export-xxxxxxxxxxxxxxx.zip”解压到一个文件夹中。


> 4. 进入“设置”-“库” ，然后点击“选择”。
> 选择你刚刚解压缩到的文件夹。


> 5. 使用我们的[[Md格式转换器]]将 Roam Research 的 Markdown 格式转换为 Obsidian 格式。

它可以用来把`#tag`变成obsidian `[[links]]` 。

它还可以将`^^highlight^^`转换为`==highlight==`

> 译者：jackiexiao